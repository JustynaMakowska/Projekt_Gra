#pragma once
class Torebka
{

public:
	Torebka(void);
	~Torebka(void);

	void Rysuj();

};


#include "Torebka.h"


Torebka::Torebka(void)
{
}


Torebka::~Torebka(void)
{
}

void Torebka::Rysuj()
{

}